


const StudentMixin = (sup) => class extends sup{
    testInfo(){
        console.log('Test info!!!!!');
    }
}



//class Aspirant extends Student{
class Aspirant extends StudentMixin(Student){
    constructor(name, kurs, finalWork){
        super(name, kurs);
        this.finalWork = finalWork;
    }
    isStudentAge(){
        return `${5 + this.kurs} учится лет`;
    }
    allAspirantInfo(){
        return `${super.allInfo()} ${this.finalWork}` 
    }
}

const aspirant1 = new Aspirant('Max', 2, '123');
 console.log(aspirant1.allInfo());
// console.log(aspirant1.isStudentAge());
// console.log(aspirant1.allAspirantInfo());
console.log(aspirant1.testInfo());