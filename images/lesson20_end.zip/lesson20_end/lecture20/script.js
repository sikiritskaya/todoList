class Student{
    constructor(name, kurs){
        this.name = name;
        this.kurs = kurs;
        
    }
    allInfo(){    
        return `${this.name} ___ ${this.kurs}`
    };

    static nameInfo(){
        console.log(`Имя: ${this.name}`)
    }

}

//const student1 = new Student('Joe', 3);
//console.log(student1.allInfo());
//Student.nameInfo();

// Static method && property
// console.log(Student.prop1);
// Student.prop1 = '123';

