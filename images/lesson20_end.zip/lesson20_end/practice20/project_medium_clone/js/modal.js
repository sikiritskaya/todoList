const showModalStory = () =>{
    const modalEl = document.querySelector('#modal-history');
    modalEl.classList.add('overlay--show');

    localStorage.setItem('titlePost', document.querySelector('#editor').textContent);

    localStorage.setItem('descrPost', document.querySelector('#editor1').textContent);

    document.querySelector('[name="title-story"]').value = localStorage.getItem('titlePost');

    document.querySelector('[name="descr-story"]').value = localStorage.getItem('descrPost');


}

document.querySelector('.btn-publish').addEventListener('click', showModalStory);