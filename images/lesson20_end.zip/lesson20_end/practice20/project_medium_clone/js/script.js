function hidePlaceholder(event) {
    let placeholder = event.target.children[0];
    if (placeholder.classList.contains('fix-placeholder') || placeholder.classList.contains('fix-placeholder-content')) {
        placeholder.hidden = true;
    }
}

//Error write title

function showPlaceholder(event) {
    let placeholder = event.target.children[0];
    if (event.target.innerText === '') {  // NEW
        placeholder.hidden = false;
    }
}

function isEmptyField(event, titlePlaceholder) {  // NEW FUNCTION
    if (event.key === 'Backspace') {
        console.log(event.target.innerText === '');
    }
    if (event.key === 'Backspace' && event.target.innerText === '') {
        event.target.innerHTML = `<span class="fix-placeholder">${titlePlaceholder}</span>`;
        event.preventDefault();
        return false;
    }
}

function editText(makeClass) {
    let range = window.getSelection().getRangeAt(0);
    let newSpan = document.createElement('span');
    newSpan.classList.add(makeClass);
    newSpan.appendChild(range.extractContents());
    range.insertNode(newSpan);
}

document.querySelector('#make-bold').addEventListener('click', function () {
    editText('strong-style');
});

document.querySelector('#make-italic').addEventListener('click', function () {
    editText('italic-style');
});


document.querySelector('#editor').addEventListener('focus', hidePlaceholder);
document.querySelector('#editor').addEventListener('blur', showPlaceholder);
document.querySelector('#editor').addEventListener('keydown', (e) =>{
    isEmptyField(e, 'Title')
} ); // NEW EVENT

document.querySelector('#editor1').addEventListener('focus', hidePlaceholder);
document.querySelector('#editor1').addEventListener('blur', showPlaceholder);
document.querySelector('#editor1').addEventListener('keydown', (e) =>{
    isEmptyField(e, 'Tell your story…')
} ); // NEW EVENT